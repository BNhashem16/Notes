/*
Navicat MySQL Data Transfer

Source Server         : Localhost
Source Server Version : 50714
Source Host           : localhost:3306
Source Database       : demo

Target Server Type    : MYSQL
Target Server Version : 50714
File Encoding         : 65001

Date: 2017-11-04 21:33:18
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `countries`
-- ----------------------------
DROP TABLE IF EXISTS `countries`;
CREATE TABLE `countries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=238 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of countries
-- ----------------------------
INSERT INTO `countries` VALUES ('1', 'Afghanistan', null, null);
INSERT INTO `countries` VALUES ('2', 'Aland Islands', null, null);
INSERT INTO `countries` VALUES ('3', 'Albania', null, null);
INSERT INTO `countries` VALUES ('4', 'Algeria', null, null);
INSERT INTO `countries` VALUES ('5', 'American Samoa', null, null);
INSERT INTO `countries` VALUES ('6', 'Andorra', null, null);
INSERT INTO `countries` VALUES ('7', 'Angola', null, null);
INSERT INTO `countries` VALUES ('8', 'Anguilla', null, null);
INSERT INTO `countries` VALUES ('9', 'Antigua and Barbuda', null, null);
INSERT INTO `countries` VALUES ('10', 'Argentina', null, null);
INSERT INTO `countries` VALUES ('11', 'Armenia', null, null);
INSERT INTO `countries` VALUES ('12', 'Aruba', null, null);
INSERT INTO `countries` VALUES ('13', 'Australia', null, null);
INSERT INTO `countries` VALUES ('14', 'Austria', null, null);
INSERT INTO `countries` VALUES ('15', 'Azerbaijan', null, null);
INSERT INTO `countries` VALUES ('16', 'Bahamas', null, null);
INSERT INTO `countries` VALUES ('17', 'Bahrain', null, null);
INSERT INTO `countries` VALUES ('18', 'Bangladesh', null, null);
INSERT INTO `countries` VALUES ('19', 'Barbados', null, null);
INSERT INTO `countries` VALUES ('20', 'Belarus', null, null);
INSERT INTO `countries` VALUES ('21', 'Belgium', null, null);
INSERT INTO `countries` VALUES ('22', 'Belize', null, null);
INSERT INTO `countries` VALUES ('23', 'Benin', null, null);
INSERT INTO `countries` VALUES ('24', 'Bermuda', null, null);
INSERT INTO `countries` VALUES ('25', 'Bhutan', null, null);
INSERT INTO `countries` VALUES ('26', 'Bolivia', null, null);
INSERT INTO `countries` VALUES ('27', 'Bosnia and Herzegovina', null, null);
INSERT INTO `countries` VALUES ('28', 'Botswana', null, null);
INSERT INTO `countries` VALUES ('29', 'Brazil', null, null);
INSERT INTO `countries` VALUES ('30', 'British Virgin Islands', null, null);
INSERT INTO `countries` VALUES ('31', 'Brunei Darussalam', null, null);
INSERT INTO `countries` VALUES ('32', 'Bulgaria', null, null);
INSERT INTO `countries` VALUES ('33', 'Burkina Faso', null, null);
INSERT INTO `countries` VALUES ('34', 'Burundi', null, null);
INSERT INTO `countries` VALUES ('35', 'Cambodia', null, null);
INSERT INTO `countries` VALUES ('36', 'Cameroon', null, null);
INSERT INTO `countries` VALUES ('37', 'Canada', null, null);
INSERT INTO `countries` VALUES ('38', 'Cape Verde', null, null);
INSERT INTO `countries` VALUES ('39', 'Cayman Islands', null, null);
INSERT INTO `countries` VALUES ('40', 'Central African Republic', null, null);
INSERT INTO `countries` VALUES ('41', 'Chad', null, null);
INSERT INTO `countries` VALUES ('42', 'Chile', null, null);
INSERT INTO `countries` VALUES ('43', 'China', null, null);
INSERT INTO `countries` VALUES ('44', 'Hong Kong', null, null);
INSERT INTO `countries` VALUES ('45', 'Macao', null, null);
INSERT INTO `countries` VALUES ('46', 'Colombia', null, null);
INSERT INTO `countries` VALUES ('47', 'Comoros', null, null);
INSERT INTO `countries` VALUES ('48', 'Congo', null, null);
INSERT INTO `countries` VALUES ('49', 'Democratic Republic of the Congo', null, null);
INSERT INTO `countries` VALUES ('50', 'Cook Islands', null, null);
INSERT INTO `countries` VALUES ('51', 'Costa Rica', null, null);
INSERT INTO `countries` VALUES ('52', 'Cote d\'Ivoire', null, null);
INSERT INTO `countries` VALUES ('53', 'Croatia', null, null);
INSERT INTO `countries` VALUES ('54', 'Cuba', null, null);
INSERT INTO `countries` VALUES ('55', 'Cyprus', null, null);
INSERT INTO `countries` VALUES ('56', 'Czech Republic', null, null);
INSERT INTO `countries` VALUES ('57', 'North Korea', null, null);
INSERT INTO `countries` VALUES ('58', 'Denmark', null, null);
INSERT INTO `countries` VALUES ('59', 'Djibouti', null, null);
INSERT INTO `countries` VALUES ('60', 'Dominica', null, null);
INSERT INTO `countries` VALUES ('61', 'Dominican Republic', null, null);
INSERT INTO `countries` VALUES ('62', 'Ecuador', null, null);
INSERT INTO `countries` VALUES ('63', 'Egypt', null, null);
INSERT INTO `countries` VALUES ('64', 'El Salvador', null, null);
INSERT INTO `countries` VALUES ('65', 'Equatorial Guinea', null, null);
INSERT INTO `countries` VALUES ('66', 'Eritrea', null, null);
INSERT INTO `countries` VALUES ('67', 'Estonia', null, null);
INSERT INTO `countries` VALUES ('68', 'Ethiopia', null, null);
INSERT INTO `countries` VALUES ('69', 'Faeroe Islands', null, null);
INSERT INTO `countries` VALUES ('70', 'Falkland Islands', null, null);
INSERT INTO `countries` VALUES ('71', 'Fiji', null, null);
INSERT INTO `countries` VALUES ('72', 'Finland', null, null);
INSERT INTO `countries` VALUES ('73', 'France', null, null);
INSERT INTO `countries` VALUES ('74', 'French Guiana', null, null);
INSERT INTO `countries` VALUES ('75', 'French Polynesia', null, null);
INSERT INTO `countries` VALUES ('76', 'Gabon', null, null);
INSERT INTO `countries` VALUES ('77', 'Gambia', null, null);
INSERT INTO `countries` VALUES ('78', 'Georgia', null, null);
INSERT INTO `countries` VALUES ('79', 'Germany', null, null);
INSERT INTO `countries` VALUES ('80', 'Ghana', null, null);
INSERT INTO `countries` VALUES ('81', 'Gibraltar', null, null);
INSERT INTO `countries` VALUES ('82', 'Greece', null, null);
INSERT INTO `countries` VALUES ('83', 'Greenland', null, null);
INSERT INTO `countries` VALUES ('84', 'Grenada', null, null);
INSERT INTO `countries` VALUES ('85', 'Guadeloupe', null, null);
INSERT INTO `countries` VALUES ('86', 'Guam', null, null);
INSERT INTO `countries` VALUES ('87', 'Guatemala', null, null);
INSERT INTO `countries` VALUES ('88', 'Guernsey', null, null);
INSERT INTO `countries` VALUES ('89', 'Guinea', null, null);
INSERT INTO `countries` VALUES ('90', 'Guinea-Bissau', null, null);
INSERT INTO `countries` VALUES ('91', 'Guyana', null, null);
INSERT INTO `countries` VALUES ('92', 'Haiti', null, null);
INSERT INTO `countries` VALUES ('93', 'Holy See', null, null);
INSERT INTO `countries` VALUES ('94', 'Honduras', null, null);
INSERT INTO `countries` VALUES ('95', 'Hungary', null, null);
INSERT INTO `countries` VALUES ('96', 'Iceland', null, null);
INSERT INTO `countries` VALUES ('97', 'India', null, null);
INSERT INTO `countries` VALUES ('98', 'Indonesia', null, null);
INSERT INTO `countries` VALUES ('99', 'Iran', null, null);
INSERT INTO `countries` VALUES ('100', 'Iraq', null, null);
INSERT INTO `countries` VALUES ('101', 'Ireland', null, null);
INSERT INTO `countries` VALUES ('102', 'Isle of Man', null, null);
INSERT INTO `countries` VALUES ('103', 'Israel', null, null);
INSERT INTO `countries` VALUES ('104', 'Italy', null, null);
INSERT INTO `countries` VALUES ('105', 'Jamaica', null, null);
INSERT INTO `countries` VALUES ('106', 'Japan', null, null);
INSERT INTO `countries` VALUES ('107', 'Jersey', null, null);
INSERT INTO `countries` VALUES ('108', 'Jordan', null, null);
INSERT INTO `countries` VALUES ('109', 'Kazakhstan', null, null);
INSERT INTO `countries` VALUES ('110', 'Kenya', null, null);
INSERT INTO `countries` VALUES ('111', 'Kiribati', null, null);
INSERT INTO `countries` VALUES ('112', 'Kuwait', null, null);
INSERT INTO `countries` VALUES ('113', 'Kyrgyzstan', null, null);
INSERT INTO `countries` VALUES ('114', 'Laos', null, null);
INSERT INTO `countries` VALUES ('115', 'Latvia', null, null);
INSERT INTO `countries` VALUES ('116', 'Lebanon', null, null);
INSERT INTO `countries` VALUES ('117', 'Lesotho', null, null);
INSERT INTO `countries` VALUES ('118', 'Liberia', null, null);
INSERT INTO `countries` VALUES ('119', 'Libyan Arab Jamahiriya', null, null);
INSERT INTO `countries` VALUES ('120', 'Liechtenstein', null, null);
INSERT INTO `countries` VALUES ('121', 'Lithuania', null, null);
INSERT INTO `countries` VALUES ('122', 'Luxembourg', null, null);
INSERT INTO `countries` VALUES ('123', 'Madagascar', null, null);
INSERT INTO `countries` VALUES ('124', 'Malawi', null, null);
INSERT INTO `countries` VALUES ('125', 'Malaysia', null, null);
INSERT INTO `countries` VALUES ('126', 'Maldives', null, null);
INSERT INTO `countries` VALUES ('127', 'Mali', null, null);
INSERT INTO `countries` VALUES ('128', 'Malta', null, null);
INSERT INTO `countries` VALUES ('129', 'Marshall Islands', null, null);
INSERT INTO `countries` VALUES ('130', 'Martinique', null, null);
INSERT INTO `countries` VALUES ('131', 'Mauritania', null, null);
INSERT INTO `countries` VALUES ('132', 'Mauritius', null, null);
INSERT INTO `countries` VALUES ('133', 'Mayotte', null, null);
INSERT INTO `countries` VALUES ('134', 'Mexico', null, null);
INSERT INTO `countries` VALUES ('135', 'Micronesia', null, null);
INSERT INTO `countries` VALUES ('136', 'Monaco', null, null);
INSERT INTO `countries` VALUES ('137', 'Mongolia', null, null);
INSERT INTO `countries` VALUES ('138', 'Montenegro', null, null);
INSERT INTO `countries` VALUES ('139', 'Montserrat', null, null);
INSERT INTO `countries` VALUES ('140', 'Morocco', null, null);
INSERT INTO `countries` VALUES ('141', 'Mozambique', null, null);
INSERT INTO `countries` VALUES ('142', 'Myanmar', null, null);
INSERT INTO `countries` VALUES ('143', 'Namibia', null, null);
INSERT INTO `countries` VALUES ('144', 'Nauru', null, null);
INSERT INTO `countries` VALUES ('145', 'Nepal', null, null);
INSERT INTO `countries` VALUES ('146', 'Netherlands', null, null);
INSERT INTO `countries` VALUES ('147', 'Netherlands Antilles', null, null);
INSERT INTO `countries` VALUES ('148', 'New Caledonia', null, null);
INSERT INTO `countries` VALUES ('149', 'New Zealand', null, null);
INSERT INTO `countries` VALUES ('150', 'Nicaragua', null, null);
INSERT INTO `countries` VALUES ('151', 'Niger', null, null);
INSERT INTO `countries` VALUES ('152', 'Nigeria', null, null);
INSERT INTO `countries` VALUES ('153', 'Niue', null, null);
INSERT INTO `countries` VALUES ('154', 'Norfolk Island', null, null);
INSERT INTO `countries` VALUES ('155', 'Northern Mariana Islands', null, null);
INSERT INTO `countries` VALUES ('156', 'Norway', null, null);
INSERT INTO `countries` VALUES ('157', 'Palestine', null, null);
INSERT INTO `countries` VALUES ('158', 'Oman', null, null);
INSERT INTO `countries` VALUES ('159', 'Pakistan', null, null);
INSERT INTO `countries` VALUES ('160', 'Palau', null, null);
INSERT INTO `countries` VALUES ('161', 'Panama', null, null);
INSERT INTO `countries` VALUES ('162', 'Papua New Guinea', null, null);
INSERT INTO `countries` VALUES ('163', 'Paraguay', null, null);
INSERT INTO `countries` VALUES ('164', 'Peru', null, null);
INSERT INTO `countries` VALUES ('165', 'Philippines', null, null);
INSERT INTO `countries` VALUES ('166', 'Pitcairn', null, null);
INSERT INTO `countries` VALUES ('167', 'Poland', null, null);
INSERT INTO `countries` VALUES ('168', 'Portugal', null, null);
INSERT INTO `countries` VALUES ('169', 'Puerto Rico', null, null);
INSERT INTO `countries` VALUES ('170', 'Qatar', null, null);
INSERT INTO `countries` VALUES ('171', 'South Korea', null, null);
INSERT INTO `countries` VALUES ('172', 'Moldova', null, null);
INSERT INTO `countries` VALUES ('173', 'Reunion', null, null);
INSERT INTO `countries` VALUES ('174', 'Romania', null, null);
INSERT INTO `countries` VALUES ('175', 'Russian Federation', null, null);
INSERT INTO `countries` VALUES ('176', 'Rwanda', null, null);
INSERT INTO `countries` VALUES ('177', 'Saint-Barthelemy', null, null);
INSERT INTO `countries` VALUES ('178', 'Saint Helena', null, null);
INSERT INTO `countries` VALUES ('179', 'Saint Kitts and Nevis', null, null);
INSERT INTO `countries` VALUES ('180', 'Saint Lucia', null, null);
INSERT INTO `countries` VALUES ('181', 'Saint-Martin', null, null);
INSERT INTO `countries` VALUES ('182', 'Saint Pierre and Miquelon', null, null);
INSERT INTO `countries` VALUES ('183', 'Saint Vincent and the Grenadines', null, null);
INSERT INTO `countries` VALUES ('184', 'Samoa', null, null);
INSERT INTO `countries` VALUES ('185', 'San Marino', null, null);
INSERT INTO `countries` VALUES ('186', 'Sao Tome and Principe', null, null);
INSERT INTO `countries` VALUES ('187', 'Saudi Arabia', null, null);
INSERT INTO `countries` VALUES ('188', 'Senegal', null, null);
INSERT INTO `countries` VALUES ('189', 'Serbia', null, null);
INSERT INTO `countries` VALUES ('190', 'Seychelles', null, null);
INSERT INTO `countries` VALUES ('191', 'Sierra Leone', null, null);
INSERT INTO `countries` VALUES ('192', 'Singapore', null, null);
INSERT INTO `countries` VALUES ('193', 'Slovakia', null, null);
INSERT INTO `countries` VALUES ('194', 'Slovenia', null, null);
INSERT INTO `countries` VALUES ('195', 'Solomon Islands', null, null);
INSERT INTO `countries` VALUES ('196', 'Somalia', null, null);
INSERT INTO `countries` VALUES ('197', 'South Africa', null, null);
INSERT INTO `countries` VALUES ('198', 'Spain', null, null);
INSERT INTO `countries` VALUES ('199', 'Sri Lanka', null, null);
INSERT INTO `countries` VALUES ('200', 'Sudan', null, null);
INSERT INTO `countries` VALUES ('201', 'Suriname', null, null);
INSERT INTO `countries` VALUES ('202', 'Svalbard and Jan Mayen Islands', null, null);
INSERT INTO `countries` VALUES ('203', 'Swaziland', null, null);
INSERT INTO `countries` VALUES ('204', 'Sweden', null, null);
INSERT INTO `countries` VALUES ('205', 'Switzerland', null, null);
INSERT INTO `countries` VALUES ('206', 'Syrian Arab Republic', null, null);
INSERT INTO `countries` VALUES ('207', 'Tajikistan', null, null);
INSERT INTO `countries` VALUES ('208', 'Thailand', null, null);
INSERT INTO `countries` VALUES ('209', 'Macedonia', null, null);
INSERT INTO `countries` VALUES ('210', 'Timor-Leste', null, null);
INSERT INTO `countries` VALUES ('211', 'Togo', null, null);
INSERT INTO `countries` VALUES ('212', 'Tokelau', null, null);
INSERT INTO `countries` VALUES ('213', 'Tonga', null, null);
INSERT INTO `countries` VALUES ('214', 'Trinidad and Tobago', null, null);
INSERT INTO `countries` VALUES ('215', 'Tunisia', null, null);
INSERT INTO `countries` VALUES ('216', 'Turkey', null, null);
INSERT INTO `countries` VALUES ('217', 'Turkmenistan', null, null);
INSERT INTO `countries` VALUES ('218', 'Turks and Caicos Islands', null, null);
INSERT INTO `countries` VALUES ('219', 'Tuvalu', null, null);
INSERT INTO `countries` VALUES ('220', 'Uganda', null, null);
INSERT INTO `countries` VALUES ('221', 'Ukraine', null, null);
INSERT INTO `countries` VALUES ('222', 'United Arab Emirates', null, null);
INSERT INTO `countries` VALUES ('223', 'United Kingdom', null, null);
INSERT INTO `countries` VALUES ('224', 'Tanzania', null, null);
INSERT INTO `countries` VALUES ('225', 'United States', null, null);
INSERT INTO `countries` VALUES ('226', 'U.S. Virgin Islands', null, null);
INSERT INTO `countries` VALUES ('227', 'Uruguay', null, null);
INSERT INTO `countries` VALUES ('228', 'Uzbekistan', null, null);
INSERT INTO `countries` VALUES ('229', 'Vanuatu', null, null);
INSERT INTO `countries` VALUES ('230', 'Venezuela', null, null);
INSERT INTO `countries` VALUES ('231', 'Viet Nam', null, null);
INSERT INTO `countries` VALUES ('232', 'Wallis and Futuna Islands', null, null);
INSERT INTO `countries` VALUES ('233', 'Western Sahara', null, null);
INSERT INTO `countries` VALUES ('234', 'Yemen', null, null);
INSERT INTO `countries` VALUES ('235', 'Zambia', null, null);
INSERT INTO `countries` VALUES ('236', 'Zimbabwe', null, null);
INSERT INTO `countries` VALUES ('237', 'South Sudan', null, null);
